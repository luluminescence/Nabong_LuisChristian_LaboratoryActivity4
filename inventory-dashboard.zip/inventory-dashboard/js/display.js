import { getStockStatus } from "./inventoryUtils.js";

export function displayProducts(products) {
    const productList = document.getElementById("productList");
    const noResultsMessage = document.getElementById("noResultsMessage");

    productList.innerHTML = "";

    if (products.length === 0) {
        noResultsMessage.textContent = "No products found";
        noResultsMessage.style.display = "block";
        return;
    }

    noResultsMessage.style.display = "none";

    products.forEach(product => {

        const {
            id,
            name,
            category,
            price,
            stock
        } = product;

        const stockStatus = getStockStatus(stock);

        const productCard = document.createElement("div");

        productCard.className = "product-card";

        productCard.innerHTML = `
            <div class="product-id">#${id}</div>

            <h3>${name}</h3>

            <p>
                <strong>Category:</strong>
                ${category}
            </p>

            <p>
                <strong>Price:</strong>
                ₱${price.toLocaleString()}
            </p>

            <p>
                <strong>Stock:</strong>
                ${stock}
            </p>

            <p>
                <strong>Status:</strong>
                ${stockStatus}
            </p>
        `;

        productList.appendChild(productCard);
    });
}

export function displayTotalInventoryValue(total) {
    const totalInventoryValue =
        document.getElementById("totalInventoryValue");

    totalInventoryValue.textContent =
        `₱${total.toLocaleString()}`;
}

export function displayLowStockCount(count) {
    const lowStockCount =
        document.getElementById("lowStockCount");

    lowStockCount.textContent = count;
}

export function displayOutOfStockCount(count) {
    const outOfStockCount =
        document.getElementById("outOfStockCount");

    outOfStockCount.textContent = count;
}