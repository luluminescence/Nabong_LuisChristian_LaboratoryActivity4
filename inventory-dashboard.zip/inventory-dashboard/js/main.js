import { products } from "./products.js";

import {
    searchProducts,
    filterProductsByCategory,
    calculateTotalInventoryValue,
    countLowStockProducts,
    countOutOfStockProducts
} from "./inventoryUtils.js";

import {
    displayProducts,
    displayTotalInventoryValue,
    displayLowStockCount,
    displayOutOfStockCount
} from "./display.js";

const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const searchBtn = document.getElementById("searchBtn");
const resetBtn = document.getElementById("resetBtn");

function displaySummary(productData) {

    const totalValue =
        calculateTotalInventoryValue(productData);

    const lowStock =
        countLowStockProducts(productData);

    const outOfStock =
        countOutOfStockProducts(productData);

    displayTotalInventoryValue(totalValue);
    displayLowStockCount(lowStock);
    displayOutOfStockCount(outOfStock);
}

function updateDisplay(productData) {
    displayProducts(productData);
    displaySummary(productData);
}

function handleSearch() {

    const query = searchInput.value;
    const category = categoryFilter.value;

    let filteredProducts = products;

    if (query.trim() !== "") {
        filteredProducts =
            searchProducts(filteredProducts, query);
    }

    filteredProducts =
        filterProductsByCategory(
            filteredProducts,
            category
        );

    updateDisplay(filteredProducts);
}

function handleReset() {

    searchInput.value = "";
    categoryFilter.value = "All";

    updateDisplay(products);
}

searchBtn.addEventListener("click", handleSearch);

resetBtn.addEventListener("click", handleReset);

updateDisplay(products);